# Next.js Markdoc Documentation Site

A static documentation website built with Next.js and Markdoc. All documentation files are stored as Markdown files in the `public` folder for easy content management.

## Features

- 📝 **Markdown-based**: Write documentation in simple Markdown files
- 🚀 **Static Generation**: Fast loading with pre-rendered pages
- 📱 **Responsive Design**: Mobile-friendly with Tailwind CSS
- 🔍 **SEO Optimized**: Meta tags and structured content
- 🎨 **Customizable**: Easy to theme and extend
- 📁 **Simple Content Management**: Just add `.md` files to the `public` folder

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Start Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the site.

### 3. Add Your Documentation

Create `.md` files in the `public` folder:

```markdown
---
title: "Your Page Title"
description: "Page description for SEO"
---

# Your Content

Write your documentation in Markdown format.
```

### 4. Build for Production

```bash
npm run build
npm run export
```

The static site will be generated in the `out` folder.

## Project Structure

```
├── public/                 # Markdown documentation files
│   ├── getting-started.md
│   ├── api-reference.md
│   └── examples.md
├── src/
│   ├── lib/
│   │   └── docs.ts        # Document parsing utilities
│   ├── markdoc/
│   │   └── config.ts      # Markdoc configuration
│   ├── pages/
│   │   ├── _app.tsx       # App layout with navigation
│   │   ├── index.tsx      # Homepage with document listing
│   │   └── [slug].tsx     # Dynamic pages for documents
│   └── styles/
│       └── globals.css    # Global styles with Tailwind
├── next.config.js         # Next.js configuration with Markdoc
├── tailwind.config.js     # Tailwind CSS configuration
└── package.json
```

## Adding Content

### Document Format

Each document should be a `.md` file in the `public` folder with optional frontmatter:

```markdown
---
title: "Document Title"
description: "SEO description"
---

# Your Content Here

Regular Markdown content...
```

### Supported Frontmatter

- `title`: Page title (falls back to filename if not provided)
- `description`: Meta description for SEO
- Additional fields can be added and accessed in the template

### File Naming

- Use kebab-case for filenames: `getting-started.md`
- Avoid spaces and special characters
- The filename becomes the URL slug: `getting-started.md` → `/getting-started`

## Customization

### Styling

Edit `src/styles/globals.css` to customize the appearance. The site uses Tailwind CSS with a custom `.markdoc` class for content styling.

### Navigation

Update `src/pages/_app.tsx` to modify the sidebar navigation. You can:
- Add/remove navigation links
- Change the layout structure
- Customize the mobile menu

### Markdoc Configuration

Extend `src/markdoc/config.ts` to add:
- Custom tags
- Custom nodes
- Custom functions
- Variables

### Layout

Modify `src/pages/_app.tsx` to change:
- Header/footer content
- Sidebar structure
- Overall page layout

## Deployment

### Static Export

```bash
npm run build
npm run export
```

Deploy the `out` folder to any static hosting service.

### Recommended Platforms

- **Vercel**: Zero-config deployment for Next.js
- **Netlify**: Drag-and-drop deployment
- **GitHub Pages**: Free hosting for public repositories
- **AWS S3**: Scalable static hosting

## Development

### Scripts

- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run start`: Start production server
- `npm run lint`: Run ESLint
- `npm run export`: Export static site

### Adding New Features

1. **Custom Components**: Add React components for Markdoc tags
2. **Search**: Integrate client-side search functionality
3. **Analytics**: Add tracking with your preferred analytics service
4. **Comments**: Integrate comment systems for documentation feedback

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - feel free to use this for your own documentation needs!

## Support

For issues and questions:
- Check the [examples](/examples) page
- Review the [API reference](/api-reference)
- Create an issue in the repository
