/** @type {import('next').NextConfig} */
const withMarkdoc = require('@markdoc/next.js');

const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true
  }
};

module.exports = withMarkdoc({
  schemaPath: './src/markdoc'
})(nextConfig);
