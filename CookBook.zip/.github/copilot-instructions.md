# Copilot Instructions

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

## Project Overview
This is a Next.js TypeScript documentation webapp that uses:
- **Markdoc** for rendering documentation content
- **Azure Blob Storage** for reading documentation files
- **Tailwind CSS** for styling
- **Turbopack** for fast development builds

## Code Guidelines
- Use TypeScript for all components and utilities
- Follow Next.js App Router patterns
- Use Tailwind CSS for styling
- Implement proper error handling for Azure Blob operations
- Use React Server Components where possible for better performance
- Follow atomic design principles for components

## Architecture Notes
- Documentation files are stored in Azure Blob Storage
- Markdoc is used to parse and render .md files
- Support for front matter in documentation files
- Implement caching strategies for blob storage content
