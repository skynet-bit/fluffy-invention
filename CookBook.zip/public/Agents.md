# Agents in AgenThink
**Version - 1.0**
---

#### Table of Contents

[Introduction](#introduction)

[How to Upload an Agent](#how-to-upload-an-agent)
   - [Prerequisites](#prerequisites)

[Step 1: Enter Agent Details](#step-1-enter-agent-details)

[Step 2: Upload Files](#step-2-upload-files)
   - [Agent Weight Files](#agent-weight-files)
   - [Agent Source Code](#agent-source-code)

[Step 3: Configure Endpoints and Environment](#step-3-configure-endpoints-and-environment)
   - [Key and Environment Configurations](#key-and-environment-configurations)

---


### Introduction
Agents are customizable components in the AgenThink AI platform that automate tasks or Thinkflows. They process inputs, make decisions, and integrate with external models and APIs. Use agents for natural language processing, computer vision, time series analysis, and audio tasks.

To create a custom agent, upload your code, select a model provider, and configure the endpoints. After you publish the agent, it appears in the **Agents Library** and is available for use in Thinkflows

This guide explains how to upload an agent in three steps.

---

### How to Upload an Agent

#### Prerequisites


Before uploading an agent, make sure you:

Have a **Creator Role account** on the platform.

Prepare the following required files:

- `Metadata.json`

- `Input.json`

- `Output.json`

Decide your agent’s **type**, **programming language**, **model provider**, and **environment**(Local, Cloud, or Hybrid).


----

### Step 1: Enter Agent Details

1. Click the **Agents tab** at the top of the navigation.

2. Click **Upload Agent** to open the agent upload page.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150898340-upload.png" /%}


3. On the **Details** page, provide:

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150893408-details.png" /%}

-  **Agent Name**: Enter a descriptive Agent name. 


{% callout type="warning" %}
**Warning**: Duplicate agent names are not allowed. The platform will display an error if the name already exists.
{% /callout %}

- **Agent Type**: Select Computer Vision, NLP, Time Series Model, or Audio.
- **Description**: A clear summary of the agent’s purpose (up to 1,000 characters).
- **Environment**: Choose Local, Cloud, or Hybrid based on your deployment needs.
- **Programming Language**: Select Python, JavaScript, Java, C++, Go, or Rust.
- **Model Provider**: Select from supported providers, such as OpenAI, Google, Hugging Face, Groq, and Meta.
- **Model Name**: Select a model available for your chosen provider (for example, if the provider is **OpenAI**, select GPT‑4o, GPT‑4 Turbo, GPT‑3.5 Turbo, or Text‑DaVinci‑003).
- **Thumbnail (Optional)**: Drag or click to upload an image for your agent.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150894438-four.png" /%}


4. Click “**Next**” to proceed with file uploads.


---

### Step 2: Upload Files

#### Agent Weight Files

1. On the **Upload Files** page, drag or click the **Upload** icon.

{% callout type="info" %}
**Note**: If you are unsure which file types to use, click on **[Guide to Weight Files](https://dev.agenthink.ai/agents/upload)**.
{% /callout %}

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150898080-upload%20files.png" /%}

2. The local file browser opens. Select the required weight files.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755859748437-Agent%20weight1.png" /%}

3. Selected files appear in the list below the upload icon.

4. Click the **Upload** icon (enabled in blue) on the right side.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755859748065-Agent%20weight%20files1.png" /%}

5. Wait for the upload to complete.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755859747700-Agent%20weight%20files.png" /%}


---

#### Agent Source Code

1. Click or drag and drop the Agent source folder into the upload area.

{% callout type="info" %}
**Note**:  Place all **source files** in a **single folder** to simplify the uploading process.
{% /callout %}

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755859747137-Agent%20source%20code.png" /%}

{% callout type="info" %}
**Note**: Click on **[Guide to Source code](https://dev.agenthink.ai/agents/upload)** to download.
{% /callout %}

2. Select the folder that contains the agent’s source code, and click **upload**.

3. Make sure it includes:

- `Metadata.json`

- `Input.json` 

- `Output.json`

4. Files display below the upload area.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150897337-source2.png" /%}


5. Click the blue **Upload** button to proceed.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150897584-source3.png" /%}






6. Click **Next** to move to the configuration stage.


---

### Step 3: Configure Endpoints and Environment


You can configure agent endpoints in two ways:

1. **Manual configure**
2. **CSV file upload**

---


**Option 1: Manually configure**

1. Enter the following for each endpoint:

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150893676-endpoint%20config.png" /%}


   - **Display Name**: A user-friendly name for the endpoint.
   - **Method**: Select GET, POST, PUT, or DELETE.
   - **URL Template**: Enter the API URL.
2. Click **Add** to save each endpoint.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150893915-endpoint.png" /%}


3. This section includes a radio button. Select this button to mark the endpoint as the **primary endpoint** for your agent.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150896820-radio%20button.png" /%}


---


**Option 2:CSV File upload**

1. Click **Guide to CSV Files**, and a pop-up will appear on the right side of the screen to download the sample CSV Excel file.

{% callout type="info" %}
**Note**: Click on **[Guide to CSV file](https://dev.agenthink.ai/agents/upload)** to download.
{% /callout %}

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150894707-guide.png" /%}


2. Open the CSV in Excel, and add as many endpoints as needed (Display Name, Method, and URL Template).

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150892858-csv%20file.png" /%}


3. Save the CSV Excel file locally.
4. Click **Upload CSV File** to import your configurations.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150893139-csvupload1.png" /%}


5. This section includes a radio button. Select this button to mark the endpoint as the **primary endpoint** for your agent.

---

#### Key and Environment Configurations


After configuring the endpoints, define the agent’s runtime settings using **Key Configurations**.

1. From the **Key** dropdown menu, select **Environment Configurations** to define values your agent will use at runtime.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150895746-key%20config.png" /%}


- **Key**: Enter the configuration  key (for example, `API_KEY`, `TIMEOUT`, or `MODEL_VERSION`).
- **Name**: Add a user-friendly label to identify the variable in the interface.
- **Value**: Enter the corresponding value (for example, an API key, time duration, or version number).

2. Click **Add**, to save the configuration.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150896000-key_add.png" /%}


These fields serve as environment variables, enabling you to adjust your agent’s settings without modifying the source code.


- **Allocate Environment Resources**:

    - Use the slider to specify the memory range (from 2 GB to 64 GB).
    - Select **CPU** or **GPU** based on the agent’s processing requirements.


{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150896279-key1.png" /%}


3. Click **Submit** to complete the setup.


- Upon successful upload, the platform displays a confirmation message. Your agent appears in the **Agents Library**, where you can use it in Thinkflows or share it with your organization.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755150897837-submitted.png" /%}


---








 