# Datasets in AgenThink

**Version – 1.0**


---


#### Table of Content

[Introduction](#introduction)

[How to Upload a Dataset](#how-to-upload-a-dataset)

- [Prerequisites](#prerequisites)

[Enter Dataset Details](#enter-dataset-details)


---


### Introduction

Datasets are structured collections of data used to support AI tasks such as Natural Language Processing, Computer Vision, and Audio Analysis. In AgenThink, creators can upload, manage, and share datasets through the Datasets Library. These datasets are critical building blocks used in Thinkflows, where they work in combination with Models and Agents.

This guide explains how to upload a datasets in two steps.

---

### How to Upload a Dataset

#### Prerequisites

Before uploading, ensure the following:

- You have a Creator Role account.

- Your dataset file meets these criteria:

  - Maximum file size: 50 GB

  - Supported formats: `.csv`, `.json`, `.tiff`.

{% callout type="info" %}
**Note**: If you are unsure which file types to use, click on **[Guide to Dataset Files](https://agenthink.ai/datasets/upload)**.
{% /callout %}

---

### Enter Dataset Details

1. Go to the **Datasets** tab from the top navigation bar.

2. Click the **+ Upload** button in the Datasets Library view.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516821863-upload.png" /%}

3. You’ll be directed to the Dataset Upload screen.

4. On the upload page, fill in the following:

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516821512-upload%20page.png" /%}

- **Dataset Name** – Enter a dataset name (max. 150 characters).

- **Description** – Provide a summary of the dataset (up to 1,000 characters).

- **Visibility** – Select one of the following:

  - Public – Shared with all users.

  - Private – Accessible only to you.

- **License** – Select a license type (GPL, MIT, Apache, etc.).

- **Dataset File** – Drag and drop your file or browse your system to upload.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516821099-upload%20dataset%20files.png" /%}


{% callout type="info" %}
**Note**:  A link to **Guide to Dataset Files** is a available beside the upload section.
{% /callout %}

5. Review your **upload dataset** files.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516819788-review%20files.png" /%}

6. Click the blue **Upload** button to proceed.
7. Click **Submit** to complete the setup.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516820336-submit%20dataset.png" /%}

Upon successful submission:

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755516820626-Successful%20message.png" /%}

- A success message appears.

- Your dataset will be added to the **Datasets Library**.

- It can now be used within your Thinkflows, combined with Models and Agents.


 