# Models in AgenThink

**Version - 1.0**

## Table of contents

[Introduction](#introduction)

[How to Upload an Model](#how-to-upload-an-model)
   - [Prerequisites](#prerequisites)
   
[Step 1: Enter Model Details](#step-1-enter-model-details)

[Step 2: Upload Files and Configure Endpoints](#step-2-upload-files-and-configure-endpoints)
   - [Model Weight Files](#model-weight-files)
   - [Model Source Code](#model-source-code)

[Configure the Model Endpoints](#configure-the-model-endpoints)
  
---

### Introduction

Models are pre-trained or custom AI systems designed to perform specific tasks such as natural language processing (NLP), computer vision, time series analysis, and audio processing. In Thinkflows, models serve as processing engines that convert inputs into actionable outputs.

This guide explains how to upload a model in two steps.

---

### How to Upload a Model

#### Prerequisites

- Have a **Creator Role account**.
-  Prepare the following required files:

    - `metadata.json`
    - `Input.json`
    - `Output.json`


---

### Step 1: Enter Model Details

1. Click the **Models** tab at the top of the navigation.
2. Click **Upload model**.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755147702612-model1.png" /%}


3. On the **upload model** page, enter the following information:

    - **Model Name** – Provide a descriptive name (maximum 150 characters).

    - **Model Type** – Select Computer Vision, NLP, Time Series, or Audio.

    - **Description** – Write a concise summary of the model (up to 1,000 characters).

{% callout type="warning" %}
Warning: Duplicate model names are not allowed. The platform will display an error if the name already exists.
{% /callout %}


{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148889240-model%20description.png" /%}

   - **Framework** – Select PyTorch, TensorFlow, JAX, or Hugging Face.
   - **License** – Select GPL, MIT, Apache 2.0, BSD, or CC BY-SA.
   - **Visibility** – Select Public, Private, or Organization.
   - **Thumbnail (optional)** – Drag or click to upload an image file.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148930983-framework.png" /%}

4. Click **Next** to proceed to the file upload stage.

---

### Step 2: Upload Files and Configure Endpoints

#### Model Weight Files

1. On the **Upload Files** page, drag or click the **Upload** icon.

{% callout type="info" %}
**Note**: If you are unsure which file types to use, click on **[Guide to Weight Files.](https://dev.agenthink.ai/models/upload)**
{% /callout %}


{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148931855-model2.png" /%}

2. The local file browser opens. Select the required weight files.
3. The selected files appear in a list to the right of the upload icon.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148932114-model3.png" /%}


4. Click the **Upload** icon (enabled in blue) on the right side.


#### Model Source Code 

1. Click or drag and drop the Model source folder into the upload area.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755838571616-model%20source%20code.png" /%}


2. Select the folder that contains the model’s source code.

{% callout type="info" %}
**Note**: Click on **[Guide to Source code.](https://dev.agenthink.ai/models/upload)** to download.
{% /callout %}

3. Make sure it includes:
 - `Metadata.json`
 - `Input.json`
 - `Output.json`
4. The selected folder files appear in a list to the right of the upload icon.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755838572018-model%20upload.png" /%}


5. Click the blue **Upload** button to proceed.

6. Click **Next** to move to the configuration stage.

---

#### Configure the Model Endpoints:

You can configure model endpoints in two ways:

1. **Manual configuration**
2. **CSV file upload**


**Option 1: Manually configure**

1. Enter the following for each endpoint:

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148932897-model6.png" /%}


  - **Display Name** – Enter the name of the endpoint.
  - **Method** – Select GET, POST, PUT, or DELETE.
  - **URL Template** – Enter the API URL template.
2. Click **Add** to save each endpoint.
3. This section includes a radio button. Select this button to mark the endpoint as the **primary endpoint** for your model.


 **Option 2: CSV File upload**

1. Click **Guide to CSV Files**, and a pop-up will appear on the right side of the screen to download the sample CSV Excel file.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148933165-model7.png" /%}

2. Open the CSV in Excel, and add as many endpoints as needed (Display Name, Method, and URL Template).

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148933419-model8.png" /%}


3. Save the CSV Excel file locally.
4. Click **Upload CSV File** to import your configurations.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148933688-model9.png" /%}


5. This section includes a radio button. Select this button to mark the endpoint as the **primary endpoint** for your model.

6. Click Submit to complete the setup.

{% figure src="https://cookbookdev.blob.core.windows.net/cookbook/1755148933961-model10.png" /%}


- Upon successful upload, the platform displays a confirmation message. Your model is now available in the **Models Library** and can be used in Thinkflows.
 