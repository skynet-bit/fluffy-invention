const fs = require('fs');
const path = require('path');
const matter = require('gray-matter');

// Recursively get all markdown files in a directory
function getAllMarkdownFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getAllMarkdownFiles(filePath));
    } else if (file.endsWith('.md')) {
      results.push(filePath);
    }
  });
  return results;
}

function generateSidebarData() {
  try {
    const docsDirectory = path.join(process.cwd(), 'public');
    if (!fs.existsSync(docsDirectory)) {
      return [];
    }

    const markdownFiles = getAllMarkdownFiles(docsDirectory)
      .filter(filePath => !path.basename(filePath).startsWith('LOGO_'));

    const documents = [];
    for (const filePath of markdownFiles) {
      const rel = path.relative(docsDirectory, filePath).replace(/\\/g, '/');
      const slug = rel.replace(/\.md$/, '');
      
      const fileContents = fs.readFileSync(filePath, 'utf8');
      const { data } = matter(fileContents);
      
      documents.push({
        slug,
        title: data.title || slug.split('/').pop() || slug,
        description: data.description || null,
      });
    }

    const sections = [];

    // Getting Started section
    const gettingStartedItems = [];
    
    // Add home page
    gettingStartedItems.push({
      title: 'Home',
      href: '/',
      slug: ''
    });

    // Add getting-started if it exists
    const gettingStartedDoc = documents.find(doc => doc.slug === 'getting-started');
    if (gettingStartedDoc) {
      gettingStartedItems.push({
        title: gettingStartedDoc.title,
        href: `/${gettingStartedDoc.slug}`,
        slug: gettingStartedDoc.slug
      });
    }

    sections.push({
      title: 'Getting Started',
      items: gettingStartedItems
    });

    // Documentation section - root level docs
    const rootDocs = documents.filter(doc => 
      !doc.slug.includes('/') && 
      doc.slug !== 'getting-started' &&
      !doc.slug.startsWith('LOGO_')
    );

    if (rootDocs.length > 0) {
      sections.push({
        title: 'Documentation',
        items: rootDocs.map(doc => ({
          title: doc.title,
          href: `/${doc.slug}`,
          slug: doc.slug
        }))
      });
    }

    // Feature sections - grouped by folder
    const folderGroups = new Map();
    
    documents
      .filter(doc => doc.slug.includes('/'))
      .forEach(doc => {
        const [folder, ...rest] = doc.slug.split('/');
        const folderTitle = folder.charAt(0).toUpperCase() + folder.slice(1);
        
        if (!folderGroups.has(folderTitle)) {
          folderGroups.set(folderTitle, []);
        }
        
        folderGroups.get(folderTitle).push({
          title: doc.title,
          href: `/${doc.slug}`,
          slug: doc.slug
        });
      });

    // Add folder sections
    folderGroups.forEach((items, folderTitle) => {
      sections.push({
        title: folderTitle,
        items: items
      });
    });

    return sections;
  } catch (error) {
    console.error('Error generating sidebar data:', error);
    return [];
  }
}

// Generate and save sidebar data
const sidebarData = generateSidebarData();
const outputPath = path.join(process.cwd(), 'src', 'data', 'sidebar.json');

// Ensure the data directory exists
const dataDir = path.dirname(outputPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

fs.writeFileSync(outputPath, JSON.stringify(sidebarData, null, 2));
console.log('Sidebar data generated successfully at:', outputPath);
