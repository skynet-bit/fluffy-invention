

import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import Markdoc from '@markdoc/markdoc';

// Recursively get all markdown files in a directory
function getAllMarkdownFiles(dir: string): string[] {
  let results: string[] = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getAllMarkdownFiles(filePath));
    } else if (file.endsWith('.md')) {
      results.push(filePath);
    }
  });
  return results;
}


export interface DocumentData {
  slug: string;
  title: string;
  description?: string | null;
  content: string;
}

export interface DocumentWithAst extends DocumentData {
  ast: any;
}

export interface DocumentMeta {
  slug: string;
  title: string;
  description?: string | null;
}

export function getDocumentBySlug(slug: string): DocumentData | null {
  try {
    const docsDirectory = path.join(process.cwd(), 'public');
    const markdownFiles = getAllMarkdownFiles(docsDirectory);
    // Find file whose relative path (from docsDirectory) without .md matches slug
    const match = markdownFiles.find((filePath) => {
      const rel = path.relative(docsDirectory, filePath).replace(/\\/g, '/');
      return rel.replace(/\.md$/, '') === slug;
    });
    if (!match) return null;
    const fileContents = fs.readFileSync(match, 'utf8');
    const { data, content } = matter(fileContents);
    
    // Get the directory of the current document for relative image paths
    const docDir = path.dirname(path.relative(docsDirectory, match)).replace(/\\/g, '/');
    
    // Normalize image links to use forward slashes and resolve relative paths
    const normalizedContent = content.replace(/!\[(.*?)\]\((.*?)\)/g, (m, alt, src) => {
      let normSrc = src.replace(/\\/g, '/');
     if (src.startsWith('http://') || src.startsWith('https://')) {
      return m; // Return original if it's an absolute URL
    }
      // If it's a relative path (doesn't start with / or http), make it relative to document location
      if (!normSrc.startsWith('/') && !normSrc.startsWith('http')) {
        if (docDir && docDir !== '.') {
          normSrc = `${normSrc}`;
        } else {
          normSrc = `/${normSrc}`;
        }
      }
      
      return `![${alt}](${normSrc})`;
    });
    
    return {
      slug,
      title: data.title || slug,
      description: data.description || null,
      content: normalizedContent,
    };
  } catch (error) {
    console.error(`Error reading document ${slug}:`, error);
    return null;
  }
}

export function getDocumentWithAst(slug: string): DocumentWithAst | null {
  try {
    const docsDirectory = path.join(process.cwd(), 'public');
    const markdownFiles = getAllMarkdownFiles(docsDirectory);
    const match = markdownFiles.find((filePath) => {
      const rel = path.relative(docsDirectory, filePath).replace(/\\/g, '/');
      return rel.replace(/\.md$/, '') === slug;
    });
    if (!match) return null;
    const fileContents = fs.readFileSync(match, 'utf8');
    const { data, content } = matter(fileContents);
    
    // Get the directory of the current document for relative image paths
    const docDir = path.dirname(path.relative(docsDirectory, match)).replace(/\\/g, '/');
    
    // Normalize image links to use forward slashes and resolve relative paths
    const normalizedContent = content.replace(/!\[(.*?)\]\((.*?)\)/g, (m, alt, src) => {
      let normSrc = src.replace(/\\/g, '/');
      
      // If it's a relative path (doesn't start with / or http), make it relative to document location
      if (!normSrc.startsWith('/') && !normSrc.startsWith('http')) {
        if (docDir && docDir !== '.') {
          normSrc = `/${docDir}/${normSrc}`;
        } else {
          normSrc = `/${normSrc}`;
        }
      }
      
      return `![${alt}](${normSrc})`;
    });
    
    const ast = Markdoc.parse(normalizedContent);
    return {
      slug,
      title: data.title || slug,
      description: data.description,
      content: normalizedContent,
      ast,
    };
  } catch (error) {
    console.error(`Error reading document ${slug}:`, error);
    return null;
  }
}

export function getAllDocumentMeta(): DocumentMeta[] {
  try {
    const docsDirectory = path.join(process.cwd(), 'public');
    if (!fs.existsSync(docsDirectory)) {
      return [];
    }
    const markdownFiles = getAllMarkdownFiles(docsDirectory)
      .filter(filePath => !path.basename(filePath).startsWith('LOGO_'));
    const documents: DocumentMeta[] = [];
    for (const filePath of markdownFiles) {
      const rel = path.relative(docsDirectory, filePath).replace(/\\/g, '/');
      const slug = rel.replace(/\.md$/, '');
      const doc = getDocumentBySlug(slug);
      if (doc) {
        documents.push({
          slug: doc.slug,
          title: doc.title,
          description: doc.description || null,
        });
      }
    }
    return documents;
  } catch (error) {
    console.error('Error reading document metadata:', error);
    return [];
  }
}

export function getAllSlugs(): string[] {
  try {
    const docsDirectory = path.join(process.cwd(), 'public');
    if (!fs.existsSync(docsDirectory)) {
      return [];
    }
    const markdownFiles = getAllMarkdownFiles(docsDirectory)
      .filter(filePath => !path.basename(filePath).startsWith('LOGO_'));
    const slugs: string[] = [];
    for (const filePath of markdownFiles) {
      const rel = path.relative(docsDirectory, filePath).replace(/\\/g, '/');
      slugs.push(rel.replace(/\.md$/, ''));
    }
    return slugs;
  } catch (error) {
    console.error('Error reading document slugs:', error);
    return [];
  }
}

export interface SidebarItem {
  title: string;
  href: string;
  slug: string;
}

export interface SidebarSection {
  title: string;
  items: SidebarItem[];
}

export function getSidebarData(): SidebarSection[] {
  try {
    const documents = getAllDocumentMeta();
    const sections: SidebarSection[] = [];

    // Getting Started section
    const gettingStartedItems: SidebarItem[] = [];
    
    // Add home page
    gettingStartedItems.push({
      title: 'Home',
      href: '/',
      slug: ''
    });

    // Add getting-started if it exists
    const gettingStartedDoc = documents.find(doc => doc.slug === 'getting-started');
    if (gettingStartedDoc) {
      gettingStartedItems.push({
        title: gettingStartedDoc.title,
        href: `/${gettingStartedDoc.slug}`,
        slug: gettingStartedDoc.slug
      });
    }

    sections.push({
      title: 'Getting Started',
      items: gettingStartedItems
    });

    // Documentation section - root level docs
    const rootDocs = documents.filter(doc => 
      !doc.slug.includes('/') && 
      doc.slug !== 'getting-started' &&
      !doc.slug.startsWith('LOGO_')
    );

    if (rootDocs.length > 0) {
      sections.push({
        title: 'Documentation',
        items: rootDocs.map(doc => ({
          title: doc.title,
          href: `/${doc.slug}`,
          slug: doc.slug
        }))
      });
    }

    // Feature sections - grouped by folder
    const folderGroups = new Map<string, SidebarItem[]>();
    
    documents
      .filter(doc => doc.slug.includes('/'))
      .forEach(doc => {
        const [folder, ...rest] = doc.slug.split('/');
        const folderTitle = folder.charAt(0).toUpperCase() + folder.slice(1);
        
        if (!folderGroups.has(folderTitle)) {
          folderGroups.set(folderTitle, []);
        }
        
        folderGroups.get(folderTitle)!.push({
          title: doc.title,
          href: `/${doc.slug}`,
          slug: doc.slug
        });
      });

    // Add folder sections
    folderGroups.forEach((items, folderTitle) => {
      sections.push({
        title: folderTitle,
        items: items
      });
    });

    return sections;
  } catch (error) {
    console.error('Error generating sidebar data:', error);
    return [];
  }
}
