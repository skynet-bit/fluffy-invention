import { useState } from 'react';
import Image from 'next/image';

interface LogoProps {
  className?: string;
}

export default function Logo({ className = "w-8 h-8" }: LogoProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    // Fallback to SVG icon if logo image fails
    return (
      <div className={`${className} bg-teal-500 rounded-lg flex items-center justify-center`}>
        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
          <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <Image 
        src="/logo.png" 
        alt="Documentation Logo" 
        width={32}
        height={32}
        className="rounded-lg breathe-logo"
        onError={() => setHasError(true)}
        priority
      />
    </div>
  );
}
