import { useState, useEffect } from 'react';
import { TocItem } from '../lib/toc';

interface TableOfContentsProps {
  items: TocItem[];
}

export default function TableOfContents({ items }: TableOfContentsProps) {
  const [activeId, setActiveId] = useState<string>('');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      {
        rootMargin: '-20% 0% -35% 0%',
        threshold: 0,
      },
    );

    // Observe all headings
    items.forEach((item) => {
      const element = document.getElementById(item.id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => observer.disconnect();
  }, [items]);

  if (items.length === 0) {
    return null;
  }

  const handleClick = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  };

  return (
    <div className="sticky top-8 py-8 pr-8">
      <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-4">Table of contents</h4>
      <nav className="space-y-1">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => handleClick(item.id)}
            className={`
              block w-full text-left text-sm transition-colors duration-200
              ${item.level === 1 ? 'font-medium' : ''}
              ${item.level === 2 ? 'pl-0' : ''}
              ${item.level === 3 ? 'pl-4' : ''}
              ${item.level === 4 ? 'pl-6' : ''}
              ${item.level === 5 ? 'pl-8' : ''}
              ${item.level === 6 ? 'pl-10' : ''}
              ${
                activeId === item.id
                  ? 'text-teal-600 dark:text-teal-400 font-medium'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
              }
            `}
          >
            {item.title}
          </button>
        ))}
      </nav>
    </div>
  );
}
