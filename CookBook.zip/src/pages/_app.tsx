import { AppProps } from 'next/app';
import Head from 'next/head';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import TableOfContents from '../components/TableOfContents';
import Logo from '../components/Logo';
import FloatingActionButton from '../components/FloatingActionButton';
import { TocItem } from '../lib/toc';
import sidebarData from '../data/sidebar.json';
import '../styles/globals.css';

interface CustomPageProps {
  tableOfContents?: TocItem[];
}

interface SidebarItem {
  title: string;
  href: string;
  slug: string;
}

interface SidebarSection {
  title: string;
  items: SidebarItem[];
}

function MyApp({ Component, pageProps }: AppProps<CustomPageProps>) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const sidebarSections = sidebarData;

  return (
    <>
      <Head>
        <title>Documentation</title>
        <meta name="description" content="Static documentation website" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        {/* Header */}
        <header className="bg-slate-800 dark:bg-slate-900 border-b border-slate-700 dark:border-slate-600">
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Logo and title */}
              <div className="flex items-center">
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  className="p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-700 lg:hidden"
                >
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </button>
                <Link href="/" className="flex items-center ml-4 lg:ml-0">
                  <div className="flex items-center">
                    <Logo className="w-8 h-8 mr-3" />
                    <span className="text-xl font-semibold text-white">Documentation</span>
                  </div>
                </Link>
              </div>

              {/* Search and actions */}
       {/*        <div className="flex items-center space-x-4">
                <div className="hidden md:block">
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </div>
                    <input
                      className="block w-64 pl-10 pr-3 py-2 border border-slate-600 rounded-md leading-5 bg-slate-700 text-slate-300 placeholder-slate-400 focus:outline-none focus:bg-slate-600 focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                      placeholder="Search documentation..."
                      type="search"
                    />
                  </div>
                </div>
                <button className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-md text-sm font-medium hidden sm:block">
                  Chat with the docs
                </button>
              </div> */}
            </div>
          </div>
        </header>

        <div className="flex">
          {/* Sidebar */}
          <nav className={`
            fixed lg:relative inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 
            transform transition-transform duration-300 ease-in-out lg:translate-x-0 mt-16 lg:mt-0
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          `}>
            <div className="flex flex-col h-full pt-5 pb-4 overflow-y-auto">
              <div className="flex-1 px-3 space-y-1">
                {/* Dynamic Navigation sections */}
                <div className="space-y-3">
                  {sidebarSections.map((section: SidebarSection, sectionIndex: number) => (
                    <div key={sectionIndex}>
                      <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        {section.title}
                      </h3>
                      <div className="mt-1 space-y-1">
                        {section.items.map((item: SidebarItem, itemIndex: number) => (
                          <Link 
                            key={itemIndex}
                            href={item.href} 
                            className="group flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 rounded-md hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                          >
                            {item.title}
                          </Link>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </nav>

          {/* Overlay for mobile */}
          {sidebarOpen && (
            <div
              className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
          )}

          {/* Main content */}
          <main className="flex-1 lg:ml-0">
            <div className="flex flex-row w-full">
              <div className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <Component {...pageProps} />
              </div>
              {pageProps.tableOfContents && pageProps.tableOfContents.length > 0 && (
                <aside className="hidden lg:block w-80 flex-shrink-0 px-4 py-8 border-l border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                  <TableOfContents items={pageProps.tableOfContents} />
                </aside>
              )}
            </div>
          </main>
        </div>
        
        {/* Floating Action Button for Dark Mode Toggle */}
        <FloatingActionButton />
      </div>
    </>
  );
}

export default MyApp;
