import React from 'react';
import { GetStaticPaths, GetStaticProps } from 'next';
import { ParsedUrlQuery } from 'querystring';
import Markdoc from '@markdoc/markdoc';
import { getDocumentBySlug, getAllSlugs, DocumentData } from '../lib/docs';
import { extractTableOfContents, TocItem } from '../lib/toc';
import config from '../markdoc/config';

interface DocPageProps {
  document: DocumentData;
  tableOfContents: TocItem[];
}

interface DocPageParams extends ParsedUrlQuery {
  slug: string[];
}

export default function DocPage({ document, tableOfContents }: DocPageProps) {
  if (!document) {
    return (
      <div className="markdoc">
        <h1>Document Not Found</h1>
        <p>The requested document could not be found.</p>
      </div>
    );
  }

  // Parse and transform the markdown content (already processed with heading IDs)
  const ast = Markdoc.parse(document.content);
  const processedMarkdoc = Markdoc.transform(ast, config);

  return (
    <div className="markdoc">
      <h1 id="title">{document?.title}</h1>
    
      {Markdoc.renderers.react(processedMarkdoc, React)}
    </div>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const slugs = getAllSlugs();
  const paths = slugs.map((slug) => ({
    params: { slug: slug.split('/') },
  }));
  return {
    paths,
    fallback: false,
  };
};
// export const getStaticPaths: GetStaticPaths = async () => {
//   const slugs = getAllSlugs();
// const paths = slugs.map((slug) => ({
//     params: { slug: slug.split('/') },
// }));

// return {
//     paths,
//     fallback: false,
// };
// };

export const getStaticProps: GetStaticProps<DocPageProps, DocPageParams> = async ({
  params,
}) => {
  if (!params?.slug) {
    return {
      notFound: true,
    };
  }
  const slug = Array.isArray(params.slug) ? params.slug.join('/') : params.slug;
  const document = getDocumentBySlug(slug);
  if (!document) {
    return {
      notFound: true,
    };
  }
  
  // Function to add IDs to headings for anchor links
  const addHeadingIds = (content: string): string => {
    return content.replace(/^(#{1,6})\s+(.+)$/gm, (match, hashes, title) => {
      const id = title
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
      return `${hashes} ${title} {#${id}}`;
    });
  };

  // Process content with heading IDs
  const processedContent = addHeadingIds(document.content);
  
  // Extract table of contents from the processed document
  const tableOfContents = extractTableOfContents(processedContent);
  
  return {
    props: {
      document: {
        ...document,
        content: processedContent
      },
      tableOfContents,
    },
  };
};
