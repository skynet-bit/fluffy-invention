import { GetStaticProps } from 'next';
import Link from 'next/link';
import { getAllDocumentMeta, DocumentMeta } from '../lib/docs';
import { TocItem } from '../lib/toc';

interface HomeProps {
  documents: DocumentMeta[];
  tableOfContents: TocItem[];
}

export default function Home({ documents }: HomeProps) {
  return (
    <div className="markdoc">
      {/* Hero section */}
      <div className="mb-12">
        <h1 id="welcome" className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Welcome to Documentation</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
          This is the documentation for our workflow automation tool that combines 
          powerful capabilities with simple markdown-based content management.
        </p>
        <p className="text-lg text-gray-500 dark:text-gray-400 mt-4">
          It covers everything from setup to usage and development. It&apos;s a work in progress 
          </p>
      </div>

      {/* Where to start section */}
     {/*  <div className="mb-12">
        <h2 id="where-to-start" className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
          Where to start 
          <span className="ml-2 text-teal-500">#</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
          <div className="bg-white rounded-lg border border-gray-200 p-6 hover:border-gray-300 transition-colors">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Quickstarts</h3>
            <p className="text-gray-600 mb-4">Jump in with our quickstart guides.</p>
            <Link 
              href="/getting-started" 
              className="inline-flex items-center text-teal-600 hover:text-teal-700 font-medium"
            >
              <span className="mr-1">→</span> Try it out
            </Link>
          </div>

   
          <div className="bg-white rounded-lg border border-gray-200 p-6 hover:border-gray-300 transition-colors">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Choose the right setup for you</h3>
            <p className="text-gray-600 mb-4">Cloud, npm, self-host...</p>
            <Link 
              href="/getting-started" 
              className="inline-flex items-center text-teal-600 hover:text-teal-700 font-medium"
            >
              <span className="mr-1">→</span> Options
            </Link>
          </div>

      
          <div className="bg-white rounded-lg border border-gray-200 p-6 hover:border-gray-300 transition-colors">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Explore integrations</h3>
            <p className="text-gray-600 mb-4">Browse our integrations library.</p>
            <Link 
              href="/examples" 
              className="inline-flex items-center text-teal-600 hover:text-teal-700 font-medium"
            >
              <span className="mr-1">→</span> Find your apps
            </Link>
          </div>


          <div className="bg-white rounded-lg border border-gray-200 p-6 hover:border-gray-300 transition-colors">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Build AI functionality</h3>
            <p className="text-gray-600 mb-4">Documentation supports building AI functionality and tools.</p>
            <Link 
              href="/advanced" 
              className="inline-flex items-center text-teal-600 hover:text-teal-700 font-medium"
            >
              <span className="mr-1">→</span> Make workflows
            </Link>
          </div>
        </div>
      </div> */}


        {documents.length > 0 && (
          <div className="mb-12">
            <h2 id="available-documentation" className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Available Documentation</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((doc) => (
            <div key={doc.slug} className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 hover:border-gray-300 dark:hover:border-gray-600 transition-colors">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{doc.title}</h3>
              {doc.description && (
            <p className="text-gray-600 dark:text-gray-300 mb-4">{doc.description}</p>
              )}
              <Link 
            href={`/${doc.slug}`} 
            className="inline-flex items-center text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 font-medium"
              >
            <span className="mr-1">→</span> Read more
              </Link>
            </div>
          ))}
            </div>
          </div>
        )}

        {documents.length === 0 && (
        <div className="bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 rounded-lg p-6 mb-12">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-200">No documentation files found</h3>
              <p className="mt-2 text-sm text-yellow-700 dark:text-yellow-300">
                Add some <code className="font-mono bg-yellow-100 dark:bg-yellow-800 px-1 rounded">.md</code> files to the{' '}
                <code className="font-mono bg-yellow-100 dark:bg-yellow-800 px-1 rounded">public</code> folder to get started.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Getting Started guide */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-8">
        <h2 id="getting-started" className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Getting Started</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">To add new documentation:</p>
        <ol className="space-y-3 text-gray-700 dark:text-gray-300">
          <li className="flex items-start">
            <span className="flex-shrink-0 w-6 h-6 bg-teal-100 dark:bg-teal-900 text-teal-600 dark:text-teal-300 rounded-full flex items-center justify-center text-sm font-medium mr-3 mt-0.5">1</span>
            Create a new <code className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm font-mono">.md</code> file in the{' '}
            <code className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm font-mono">public</code> folder
          </li>
          <li className="flex items-start">
            <span className="flex-shrink-0 w-6 h-6 bg-teal-100 dark:bg-teal-900 text-teal-600 dark:text-teal-300 rounded-full flex items-center justify-center text-sm font-medium mr-3 mt-0.5">2</span>
            Add frontmatter with title and description (optional)
          </li>
          <li className="flex items-start">
            <span className="flex-shrink-0 w-6 h-6 bg-teal-100 dark:bg-teal-900 text-teal-600 dark:text-teal-300 rounded-full flex items-center justify-center text-sm font-medium mr-3 mt-0.5">3</span>
            Write your content in Markdown format
          </li>
          <li className="flex items-start">
            <span className="flex-shrink-0 w-6 h-6 bg-teal-100 dark:bg-teal-900 text-teal-600 dark:text-teal-300 rounded-full flex items-center justify-center text-sm font-medium mr-3 mt-0.5">4</span>
            The page will be automatically available at <code className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm font-mono">/filename</code>
          </li>
        </ol>

        <div className="mt-8">
          <h3 id="example-markdown-file" className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Example Markdown File</h3>
          <pre className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 overflow-x-auto">
            <code className="text-sm text-gray-800 dark:text-gray-200">{`---
title: "Getting Started"
description: "Learn how to use this documentation site"
---

# Getting Started

This is your content in Markdown format.

## Features

- Static site generation
- Markdown support with Markdoc
- Responsive design
- Easy to deploy`}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const documents = getAllDocumentMeta();
  
  // Generate table of contents for the homepage
  const tableOfContents: TocItem[] = [
    { id: 'welcome', title: 'Welcome to Documentation', level: 1 },
   // { id: 'where-to-start', title: 'Where to start', level: 2 },
    { id: 'available-documentation', title: 'Available Documentation', level: 1 },
    { id: 'agents', title: 'Agents', level: 2 },
    { id: 'datasets', title: 'Datasets', level: 3 },
    { id: 'models', title: 'Models', level: 3 },
  ];

  return {
    props: {
      documents,
      tableOfContents,
    },
  };
};
