import { Config } from '@markdoc/markdoc';

const config: Config = {
  tags: {
    figure: {
      render: 'img',
      attributes: {
        src: { type: String, required: true },
        alt: { type: String },
        title: { type: String },
        width: { type: String },
        height: { type: String }
      },
      transform(node, config) {
        const attributes = node.transformAttributes(config);
        return {
          $$mdtype: 'Tag',
          name: 'img',
          attributes: {
            src: attributes.src,
            alt: attributes.alt || '',
            title: attributes.title,
            width: attributes.width,
            height: attributes.height,
            className: 'markdoc-figure'
          }
        };
      }
    },
    callout: {
      render: 'div',
      attributes: {
        type: { type: String, default: 'info' }
      },
      transform(node, config) {
        const attributes = node.transformAttributes(config);
        const children = node.transformChildren(config);
        const type = attributes.type || 'info';
        
        return {
          $$mdtype: 'Tag',
          name: 'div',
          attributes: {
            className: `callout callout-${type}`
          },
          children: [
            {
              $$mdtype: 'Tag',
              name: 'div',
              attributes: { className: 'callout-title' },
              children: [type.charAt(0).toUpperCase() + type.slice(1)]
            },
            {
              $$mdtype: 'Tag',
              name: 'div',
              attributes: { className: 'callout-content' },
              children
            }
          ]
        };
      }
    }
  },
  nodes: {
    heading: {
      render: 'h1',
      attributes: {
        id: { type: String },
        level: { type: Number }
      },
      transform(node, config) {
        const attributes = node.transformAttributes(config);
        const children = node.transformChildren(config);
        const level = attributes.level || 1;
        
        // Extract text content for ID generation
        const textContent = children
          .map((child: any) => (typeof child === 'string' ? child : ''))
          .join('')
          .trim();
        
        // Generate ID if not provided
        const id = attributes.id || textContent
          .toLowerCase()
          .replace(/[^\w\s-]/g, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
          .replace(/^-|-$/g, '');

        return {
          $$mdtype: 'Tag',
          name: `h${level}`,
          attributes: { id },
          children
        };
      }
    }
  },
  functions: {},
  variables: {},
};

export default config;
